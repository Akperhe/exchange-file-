package com.joelson.delgram.model2

data class DataX(
    val __v: Int,
    val _id: String,
    val commentText: String,
    val dateOfCommet: String,
    val id: String,
    val post_id: String,
    val user_id: UserIdX
)
package com.joelson.delgram.model2

data class CommentResponse(
    val `data`: List<DataX>
)
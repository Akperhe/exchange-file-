package com.joelson.delgram.model2

data class MyPostResponse(
    val `data`: List<Data>,
    val status: String
)
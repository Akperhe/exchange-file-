package com.joelson.delgram.model2

data class MyCommentResponse(
    val __v: Int,
    val _id: String,
    val commentText: String,
    val dateOfCommet: String,
    val post_id: String,
    val user_id: String
)
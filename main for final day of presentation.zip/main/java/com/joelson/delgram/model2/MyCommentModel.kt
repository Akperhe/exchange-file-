package com.joelson.delgram.model2

data class MyCommentModel(
    var commentText: String

)

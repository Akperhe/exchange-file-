package com.joelson.delgram.model2

data class Userid(
    val profilePicture: String,
    val userName: String
)
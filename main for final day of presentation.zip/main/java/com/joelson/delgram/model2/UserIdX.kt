package com.joelson.delgram.model2

data class UserIdX(
    val profilePicture: String,
    val userName: String
)
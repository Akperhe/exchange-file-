package com.joelson.delgram.viewModel

import android.util.Log
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.joelson.delgram.Application
import com.joelson.delgram.apiService.RetrofitProvider
import com.joelson.delgram.model.*
import kotlinx.coroutines.*
import retrofit2.Call

class LoginViewModel: ViewModel() {
    private val exceptionHandler = CoroutineExceptionHandler { coroutineContext, throwable ->
        throwable.message?.let { Log.e("Exception!", it) }
    }
    private val scope = CoroutineScope(Job() + exceptionHandler)

    val message: MutableLiveData<String> = MutableLiveData()
    val isRegistrationSuccessful: MutableLiveData<Boolean> = MutableLiveData(false)
    val isLoading: MutableLiveData<Boolean> = MutableLiveData(false)


    fun login(user: LoginModel) {
        isLoading.postValue(true)
        scope.launch {
            val response = RetrofitProvider.service.loginUser(user)
            Log.e("ViewModel Response", response.toString())
            if (response.isSuccessful){
                response.body()?.let {
                    Application.sessionManager.apply {
                        firstName = it.user.firstName
                        lastName = it.user.lastName
                        userName = it.user.userName
                        email = it.user.email
                        isOnline = it.user.isOnline
                        phoneNumber = it.user.phoneNumber
                        stack = it.user.stack
                        token = it.token
                        isUserSignedIn = true
                        id = it.user._id.toString()
                        Log.i("innLogV", Application.sessionManager.profilePicUrl.toString())
                        Log.i("innLogV", Application.sessionManager.id.toString())
                        Log.i("innLogV", Application.sessionManager.firstName.toString())
                        userId = it.user._id
                        Log.i("innLogVUsI", Application.sessionManager.userId.toString())
                        profilePicUrl =it.user.profilePicture
                        location =it.user.location
                        Log.i("Loc", Application.sessionManager.location.toString())

                    }
                }
                message.postValue("User login! with username ${Application.sessionManager.userName}")
                isRegistrationSuccessful.postValue(true)
                isLoading.postValue(false)
            } else {
                message.postValue(response.raw().message)
                isLoading.postValue(false)
            }
        }
    }

}

package com.joelson.delgram.viewModel

import android.util.Log
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.joelson.delgram.Application
import com.joelson.delgram.R
import com.joelson.delgram.apiService.RetrofitProvider
import com.joelson.delgram.databinding.PostItemBinding
import com.joelson.delgram.model.LoginModel
import kotlinx.coroutines.CoroutineExceptionHandler
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch

class MainActivityViewModel: ViewModel() {
    private val exceptionHandler = CoroutineExceptionHandler { coroutineContext, throwable ->
        throwable.message?.let { Log.e("Exception!", it) }
    }
    private val scope = CoroutineScope(Job() + exceptionHandler)
    private lateinit var binding: PostItemBinding
    val isAddedToFAV: MutableLiveData<Boolean> = MutableLiveData(true)


    fun favToggle() {
        //isAddedToFAV.postValue(true)
        scope.launch {

            Log.i("ViewModel Response", "function call in mainviewmodel")

            if(binding.favourite.tag == binding.favourite.setTag(R.drawable.ic_add_to_favorite)){
                isAddedToFAV.postValue(true)
                binding.favourite.setImageResource(R.drawable.ic_add_to_favorite2)

            } else {
                isAddedToFAV.postValue(false)
                binding.favourite.setImageResource(R.drawable.ic_add_to_favorite)
            }

        }
    }

}

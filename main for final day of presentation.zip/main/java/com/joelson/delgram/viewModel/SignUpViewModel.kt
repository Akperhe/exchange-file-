package com.joelson.delgram.viewModel

import android.util.Log
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.joelson.delgram.apiService.RetrofitProvider
import com.joelson.delgram.model.*
import kotlinx.coroutines.*
import retrofit2.Call
import android.widget.Toast

import org.json.JSONObject
import java.lang.Exception


class SignUpViewModel: ViewModel() {
    private val exceptionHandler = CoroutineExceptionHandler { coroutineContext, throwable ->
        throwable.message?.let { Log.e("Exception!", it) }
    }
    private val scope = CoroutineScope(Job() + exceptionHandler)

    val message: MutableLiveData<String> = MutableLiveData("")
    val isRegistrationSuccessful: MutableLiveData<Boolean> = MutableLiveData(false)
    val isLoading: MutableLiveData<Boolean> = MutableLiveData(false)


    fun signUp(user: SignupModel){
        isLoading.postValue(true)
        scope.launch {
            val response = RetrofitProvider.service.signUpUser(user)
          //  Log.e("ViewModel Response", response.toString())
            //response.body()?.message?.let { Log.e("ViewModel Response", it) }

            if (response.isSuccessful){
                message.postValue("User signed up! with username")
                isRegistrationSuccessful.postValue(true)
                isLoading.postValue(false)
            }else{
               // message.postValue(response.raw().message)
                message.postValue("${response.raw().message}: ${response.body()?.message}")
                isLoading.postValue(false)

            }
        }
    }

}

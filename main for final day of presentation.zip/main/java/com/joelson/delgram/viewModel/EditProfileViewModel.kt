package com.joelson.delgram.viewModel

import android.util.Log
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.joelson.delgram.Application
import com.joelson.delgram.apiService.RetrofitProvider
import com.joelson.delgram.model.UpdateProfileDetailModel
import kotlinx.coroutines.CoroutineExceptionHandler
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import okhttp3.MultipartBody

class EditProfileViewModel : ViewModel() {
    val exceptionHandler = CoroutineExceptionHandler { coroutineContext, throwable ->
        Log.e("Exception!", throwable.message.toString())
    }
    val scope = CoroutineScope(Job() + exceptionHandler)

    val isLoading: MutableLiveData<Boolean> = MutableLiveData(false)
    val message: MutableLiveData<String> = MutableLiveData()


    fun updateUserprofileImage(requestBody: MultipartBody) {
        scope.launch {
            isLoading.postValue(true)
            val response = Application.sessionManager.userId?.let {

                RetrofitProvider.service.uploadProfilePic(it, requestBody)
            }
            if (response != null) {
                Log.e("ViewModel Response", response.toString())

                if (response.isSuccessful) {
                    message.postValue("${response.body()}: ${response.body()} registered!")
                    response.body()?.data?.let {
                        Application.sessionManager.apply {
                            isOnline = it.isOnline
                            email = it.email
                            firstName = it.firstName
                            lastName = it.lastName
                            phoneNumber = it.phoneNumber
                            stack = it.stack
                            userName = it.userName
                            profilePicUrl = it.profilePicture
                            bio = it.bio
                            gender = it.gender
                            website = it.website
                            Log.i("innEdvMPri", Application.sessionManager.profilePicUrl.toString())
                            Log.i("innEdvMPri", Application.sessionManager.id.toString())
                            Log.i("innEdvMPri", Application.sessionManager.firstName.toString())

                        }
                    }
                    isLoading.postValue(false)
                } else {
                    Log.i("innEdvMPre", Application.sessionManager.profilePicUrl.toString())
                    Log.i("innEdvMPre", Application.sessionManager.id.toString())
                    Log.i("innEdvMPre", Application.sessionManager.firstName.toString())

                    message.postValue("${response.raw().message}: ${response.body()}")
                    isLoading.postValue(false)
                }
            }
        }
    }

    fun updateUserProfileDetails(userUpdateProfileDetails: UpdateProfileDetailModel) {
        isLoading.postValue(true)
        scope.launch {
            val response = Application.sessionManager.userId?.let {
                RetrofitProvider.service.updateProfileDetails(it, userUpdateProfileDetails)
            }

            if (response != null) {
                if (response.isSuccessful) {
                    response.body()?.data?.let {
                        Application.sessionManager.apply {
                            isOnline = it.isOnline
                            email = it.email
                            firstName = it.firstName
                            lastName = it.lastName
                            Log.i("innLl", it.lastName.toString())
                            phoneNumber = it.phoneNumber
                            stack = it.stack
                            userName = it.userName
                            profilePicUrl = it.profilePicture
                            bio = it.bio
                            gender = it.gender
                            website = it.website
                            location = it.location
                        }
                    }
                    Log.i("innF", Application.sessionManager.firstName.toString())
                    Log.i("innL", Application.sessionManager.lastName.toString())
                    Log.i("innG", Application.sessionManager.gender.toString())
                    Log.i("innL", Application.sessionManager.location.toString())
                    Log.i("innS", Application.sessionManager.stack.toString())


                    message.postValue("${response.body()}: ${response.body()} registered!")
                    isLoading.postValue(false)
                } else isLoading.postValue(false)
            }

        }
    }
}
package com.joelson.delgram.viewModel

import android.util.Log
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.joelson.delgram.Application
import com.joelson.delgram.apiService.RetrofitProvider
import com.joelson.delgram.model.UpdateProfileDetailModel
import com.joelson.delgram.model2.DataX
import com.joelson.delgram.model2.MyCommentModel
import kotlinx.coroutines.*

class CommentViewModel : ViewModel() {
    val post: MutableLiveData<List<DataX>> = MutableLiveData()
    val status: MutableLiveData<Boolean> = MutableLiveData(false)
    val isLoading: MutableLiveData<Boolean> = MutableLiveData(false)
    val message: MutableLiveData<String> = MutableLiveData()
    val isLoading1: MutableLiveData<Boolean> = MutableLiveData(true)//1add
    val status1: MutableLiveData<Boolean> = MutableLiveData(false)//add2


    val exceptionHandler = CoroutineExceptionHandler { coroutineContext, throwable ->
        Log.e("Exception!", throwable.message.toString())
    }
    val scope = CoroutineScope(Job() + exceptionHandler)


    fun getAllComments(postId : String) {
        try {
            CoroutineScope(Dispatchers.IO).launch {
                val posts: List<DataX> = RetrofitProvider.service.getAllComments(postId).data
                post.postValue(posts)
                isLoading1.postValue(false) //add3
            }
        } catch (e: Exception) {
            Log.e("ViewModel", e.message.toString())
        }
    }


    fun postComment(myComment: MyCommentModel) {
        isLoading.postValue(true)
        scope.launch {

            val response = Application.sessionManager.postId?.let {
                RetrofitProvider.service.postComment(it, myComment)
            }

            if (response != null) {
                if (response.isSuccessful) {
                    response.body()?.let {
                        Application.sessionManager.apply {
                           // isOnline = it.isOnline
                            //email = it.email
                            //firstName = it.firstName
                            //lastName = it.lastName
                            //phoneNumber = it.phoneNumber
                            //stack = it.stack
                            //userName = it.userName
                            //profilePicUrl = it.profilePicture
                            //bio = it.bio
                            //gender = it.gender
                            //website = it.website
                        }
                    }
                    status.postValue(true)
                    message.postValue("${response.body()}: ${response.body()} registered!")
                    isLoading.postValue(false)
                } else {
                    message.postValue(response.raw().message)
                    isLoading.postValue(false)
                }

            }

        }
    }

}
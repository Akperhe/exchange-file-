package com.joelson.delgram.viewModel

import android.util.Log
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.joelson.delgram.Application
import com.joelson.delgram.apiService.RetrofitProvider
import com.joelson.delgram.model.Data
import com.joelson.delgram.model.DataX
import com.joelson.delgram.model.PostResponse
import kotlinx.coroutines.*
import okhttp3.MultipartBody

class PostViewModel : ViewModel() {
    val post: MutableLiveData<List<DataX>> = MutableLiveData()
    var status = MutableLiveData<Int>()
    val isLoading: MutableLiveData<Boolean> = MutableLiveData(false)
    val message: MutableLiveData<String> = MutableLiveData()


    val exceptionHandler = CoroutineExceptionHandler { coroutineContext, throwable ->
        Log.e("Exception!", throwable.message.toString())
    }
    val scope = CoroutineScope(Job() + exceptionHandler)


    fun getAllPost() {
        try {
            CoroutineScope(Dispatchers.IO).launch {
                val posts: List<DataX> = RetrofitProvider.service.getAllPost().data
                post.postValue(posts)
                Log.i("innPotV", Application.sessionManager.id.toString())
                Log.i("innPotV", Application.sessionManager.firstName.toString())

            }
        } catch (e: Exception) {
            Log.e("ViewModel", e.message.toString())
        }
    }



    fun makeAPost(requestBody: MultipartBody) {

        scope.launch {
            isLoading.postValue(true)
            val response = Application.sessionManager.id?.let {
                RetrofitProvider.service.makeAPost(requestBody)
            }
            if (response != null) {
                Log.e("ViewModel Response", response.toString())

                if (response.isSuccessful) {
                    Log.e("Posted", "Posted")
                    message.postValue("${response.body()}: ${response.body()} registered!")
                    response.body()?.let {
                        Application.sessionManager.apply {
                           /* no need for response here ples
                            isOnline = it.isOnline
                            email = it.email
                            firstName = it.firstName
                            lastName = it.lastName
                            phoneNumber = it.phoneNumber
                            stack = it.stack
                            userName = it.userName
                            profilePicUrl = it.profilePicture
                            bio = it.bio
                            gender = it.gender
                            website = it.website
                            */
                        }
                    }
                    isLoading.postValue(false)
                } else {
                    message.postValue("${response.raw().message}: ${response.body()}")
                    isLoading.postValue(false)
                }
            }
        }
    }



    fun isTogglePost() {
        try {
            CoroutineScope(Dispatchers.IO).launch {
                val posts: List<DataX> = RetrofitProvider.service.getAllPost().data
                post.postValue(posts)
            }
        } catch (e: Exception) {
            Log.e("ViewModel", e.message.toString())
        }
    }





}
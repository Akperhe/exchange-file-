package com.joelson.delgram.viewModel

import android.util.Log
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.joelson.delgram.apiService.RetrofitProvider
import com.joelson.delgram.model.DataX
import com.joelson.delgram.model2.Data
import kotlinx.coroutines.*

class MyPostViewModel : ViewModel() {
    val post: MutableLiveData<List<Data>> = MutableLiveData()
    var status = MutableLiveData<Int>()
    val isLoading: MutableLiveData<Boolean> = MutableLiveData(false)
    val message: MutableLiveData<String> = MutableLiveData()


    val exceptionHandler = CoroutineExceptionHandler { coroutineContext, throwable ->
        Log.e("Exception!", throwable.message.toString())
    }
    val scope = CoroutineScope(Job() + exceptionHandler)

    fun getAllMyPost() {
        try {
            CoroutineScope(Dispatchers.IO).launch {
                val posts: List<Data> = RetrofitProvider.service.getAllMyPost().data
                post.postValue(posts)
            }
        } catch (e: Exception) {
            Log.e("ViewModel", e.message.toString())
        }
    }

}
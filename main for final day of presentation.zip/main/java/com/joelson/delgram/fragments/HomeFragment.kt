package com.joelson.delgram.fragments

import android.os.Bundle
import android.util.Log
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.core.view.isVisible
import androidx.fragment.app.viewModels
import androidx.recyclerview.widget.DividerItemDecoration
import androidx.recyclerview.widget.LinearLayoutManager
import com.joelson.delgram.R
import com.joelson.delgram.databinding.FragmentHomeBinding
import com.joelson.delgram.databinding.PostItemBinding
import com.joelson.delgram.viewModel.MainActivityViewModel
import com.joelson.delgram.viewModel.PostViewModel
import com.smith.contactapp.adapter.PostAdapter
import com.smith.contactapp.adapter.StoryAdapter


class HomeFragment : Fragment() {
    private lateinit var binding2: PostItemBinding
    private lateinit var binding: FragmentHomeBinding
    private lateinit var postAdapter: PostAdapter
    private lateinit var storyAdapter: StoryAdapter
    private val viewModel by viewModels<PostViewModel>()
    private val mainActivityViewModel by viewModels<MainActivityViewModel>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        arguments?.let {

        }
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        binding = FragmentHomeBinding.inflate(inflater,container,false)
        //binding = ActivityMainBinding.inflate(layoutInflater)
        Log.i("non", "postiteminflate")
        binding2 = PostItemBinding.inflate(layoutInflater)
        var isCliked2 = binding2.favourite//.setImageResource(R.drawable.ic_add_to_favorite2)
        isCliked2.setImageResource(R.drawable.ic_add_to_favorite2)
        Log.i("non", "postiteminflatedone")
        var firstClick = true
        var bool: Boolean = true
        postAdapter = PostAdapter(listOf(),this

            /*,  {
            Log.i("non", "nonnnnnn")


/*

           // binding2.favourite.setOnClickListener {
             //   Log.i("ViewModel Response", "function call in mainActivity")

                if(bool ==true){
                    //isAddedToFAV.postValue(true)
                    binding2.favourite.setImageResource(R.drawable.ic_add_to_favorite2)
                    bool = false
                    Log.i("ViewModel Response", "function call in homefragment adpater in if")
                    Toast.makeText(context, "Added to favourite22", Toast.LENGTH_SHORT).show()
                   // postAdapter.datas = listOf(it)
                    postAdapter.notifyDataSetChanged()
                    Toast.makeText(context, "notify post adapter", Toast.LENGTH_SHORT).show()

                } else {
                    //isAddedToFAV.postValue(false)
                    binding2.favourite.setImageResource(R.drawable.ic_add_to_favorite)
                    bool=true
                    Log.i("ViewModel Response", "function call in homefragment adpater in else")
                    Toast.makeText(context, "Removed from favourite22", Toast.LENGTH_SHORT).show()
                    //postAdapter.datas = listOf(it)
                    postAdapter.notifyDataSetChanged()
                    Toast.makeText(context, "notify post adapter", Toast.LENGTH_SHORT).show()

                }




           // }


            //.setImageResource(R.drawable.ic_add_to_favorite2)
       */
        }

        */

        )
        storyAdapter = StoryAdapter(listOf())

   /*
        {
            Log.i("non", "nonnnnnnlove2")
            val isCliked = binding2.favourite//.setImageResource(R.drawable.ic_add_to_favorite2)
            isCliked.setImageResource(R.drawable.ic_add_to_favorite2)
            Log.i("non", "nonnnnnn2222")
            Toast.makeText(context, "you love this post", Toast.LENGTH_SHORT).show()
            //.setImageResource(R.drawable.ic_add_to_favorite2)
        }
*/
        binding.postsRecyclerView.apply {
            layoutManager = LinearLayoutManager(requireContext())
            addItemDecoration(DividerItemDecoration(context, LinearLayoutManager.VERTICAL))
            //hasFixedSize()
            adapter =postAdapter

        }

        binding.storyRecyclerView.apply {
            //layoutManager = LinearLayoutManager(requireContext())
            //addItemDecoration(DividerItemDecoration(context, LinearLayoutManager.VERTICAL))
            //hasFixedSize()
            adapter =storyAdapter

        }


        Log.i("image","glideview")
        viewModel.apply {
            Log.i("image","glide")
            getAllPost()
            Log.i("image","glide2")
            post.observe(requireActivity()) {

                postAdapter.datas = it
                postAdapter.notifyDataSetChanged()


                storyAdapter.datas =it
                storyAdapter.notifyDataSetChanged()
                binding.prog.isVisible = false
            }


        }

        mainActivityViewModel.apply {
            isAddedToFAV.observe(requireActivity()){
                favToggle()
                Log.i("ViewModel Response", "observing in homefrag")
            }
        }
        Log.i("ViewModel Response", "observing in homefrag")



        Log.i("ViewModel Response", "call in oncreat of fragment before listen")
        //var bool: Boolean = false


        return binding.root
    }



    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        Log.i("ViewModel Response", "call in oncreatView of fragment before listen")

        var bool: Boolean = false
        binding2.favourite.setOnClickListener {


            if(bool ==true){
                //isAddedToFAV.postValue(true)
                binding2.favourite.setImageResource(R.drawable.ic_add_to_favorite2)
                bool = false
                Log.i("ViewModel Response", "call in oncreat of fragment if")

            } else {
                //isAddedToFAV.postValue(false)
                binding2.favourite.setImageResource(R.drawable.ic_add_to_favorite)
                bool=true
                Log.i("ViewModel Response", "call in oncreat of fragment ele")
            }


        }
    }










}
package com.joelson.delgram.fragments

import android.os.Bundle
import android.util.Log
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.core.view.isVisible
import androidx.fragment.app.viewModels
import androidx.recyclerview.widget.DividerItemDecoration
import androidx.recyclerview.widget.LinearLayoutManager
import com.joelson.delgram.R
import com.joelson.delgram.databinding.ChatItemBinding
import com.joelson.delgram.databinding.FragmentChatBinding
import com.joelson.delgram.databinding.FragmentHomeBinding
import com.joelson.delgram.databinding.PostItemBinding
import com.joelson.delgram.viewModel.PostViewModel
import com.smith.contactapp.adapter.ChatAdapter
import com.smith.contactapp.adapter.PostAdapter

class ChatFragment : Fragment() {
    private lateinit var binding2: ChatItemBinding
    private lateinit var binding: FragmentChatBinding
    private lateinit var chatAdapter: ChatAdapter
    private val viewModel by viewModels<PostViewModel>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        arguments?.let {

        }
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?,
                              savedInstanceState: Bundle?): View? {
        // Inflate the layout for this fragment
        binding = FragmentChatBinding.inflate(inflater,container,false)
        //binding = ActivityMainBinding.inflate(layoutInflater)

        binding2 = ChatItemBinding.inflate(layoutInflater)
        chatAdapter = ChatAdapter(listOf())

        binding.chatRecyclerView.apply {
            layoutManager = LinearLayoutManager(requireContext())
            addItemDecoration(DividerItemDecoration(context, LinearLayoutManager.VERTICAL))
           // hasFixedSize()
            adapter =chatAdapter
        }


        Log.i("image","glideview")
        viewModel.apply {
            Log.i("image","glide")
            getAllPost()
            Log.i("image","glide2")
            post.observe(requireActivity()) {
                chatAdapter.datas = it
                chatAdapter.notifyDataSetChanged()
                binding.prog.isVisible = false
            }


        }
        return binding.root
    }

    companion object {
        /**
         * Use this factory method to create a new instance of
         * this fragment using the provided parameters.
         *
         * @param param1 Parameter 1.
         * @param param2 Parameter 2.
         * @return A new instance of fragment ChatFragment.
         */
        // TODO: Rename and change types and number of parameters
        @JvmStatic
        fun newInstance(param1: String, param2: String) =
                ChatFragment().apply {
                    arguments = Bundle().apply {

                    }
                }
    }
}
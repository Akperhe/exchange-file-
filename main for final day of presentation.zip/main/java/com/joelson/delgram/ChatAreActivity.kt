package com.joelson.delgram

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import com.joelson.delgram.databinding.ActivityChatAreBinding
import com.joelson.delgram.databinding.ActivityChatBinding

class ChatAreActivity : AppCompatActivity() {
    private lateinit var binding: ActivityChatAreBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityChatAreBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.send.setOnClickListener {
            binding.input.setText("")
        }
        binding.dotMenu.setOnClickListener {
            val intent: Intent = Intent(this, ChatActivity::class.java)
            startActivity(intent)
        }

        binding.fhNotification.setOnClickListener {
            Toast.makeText(this, "No Notfication Yet", Toast.LENGTH_LONG ).show()

        }


    }
}
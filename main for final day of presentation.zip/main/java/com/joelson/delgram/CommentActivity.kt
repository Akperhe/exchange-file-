package com.joelson.delgram

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.View
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.isVisible
import androidx.recyclerview.widget.DividerItemDecoration
import androidx.recyclerview.widget.LinearLayoutManager
import com.joelson.delgram.databinding.ActivityCommentBinding
import com.joelson.delgram.model2.MyCommentModel
import com.joelson.delgram.viewModel.CommentViewModel
import com.smith.contactapp.adapter.CommentsAdapter


class CommentActivity : AppCompatActivity() {

    private lateinit var binding: ActivityCommentBinding
    private lateinit var commentAdapter: CommentsAdapter
    private val viewModel by viewModels<CommentViewModel>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityCommentBinding.inflate(layoutInflater)
        setContentView(binding.root)
        var postId = intent.getStringExtra("postId")
        Log.i("ExtraPut", postId.toString())
        Application.sessionManager.postId = postId
        commentAdapter = CommentsAdapter(listOf())

        binding.commentsRecyclerView.apply {
            layoutManager = LinearLayoutManager(this@CommentActivity)
            addItemDecoration(DividerItemDecoration(context, LinearLayoutManager.VERTICAL))
            // hasFixedSize()
            adapter = commentAdapter
        }

        viewModel.apply {
            Log.i("image", "glide")
            postId?.let { getAllComments(it) }
            Log.i("image", "glide2")
            post.observe(this@CommentActivity) {
                commentAdapter.datas = it
                commentAdapter.notifyDataSetChanged()
                binding.prog.isVisible = false
            }
        }

        binding.backImage.setOnClickListener {
            val intent: Intent = Intent(this, MainActivity::class.java)
            startActivity(intent)
        }

        viewModel.isLoading.observe(this, {
            if (it) binding.prog.visibility = View.VISIBLE else binding.prog.visibility = View.GONE
        })
        viewModel.isLoading1.observe(this, {
            if (it) binding.prog.visibility = View.VISIBLE else binding.prog.visibility = View.GONE
        }) //add4



        viewModel.status.observe(this) {
            if (it) {

                viewModel.apply {
                    Log.i("image", "glide")
                    postId?.let { getAllComments(it) }
                    Log.i("image", "glide2")
                    post.observe(this@CommentActivity) {
                        commentAdapter.datas = it
                        commentAdapter.notifyDataSetChanged()
                        binding.prog.isVisible = false
                    }
                }

            }
        }

        binding.postCommentText.setOnClickListener {
            var comment = binding.commentText.text.toString()

            if (comment.isNotEmpty()) {
                //binding.prog.isVisible=true
                Log.i("texttttt", comment)
                var myComment: MyCommentModel = MyCommentModel(comment)
                //binding.prog.isVisible=true
                binding.commentText.setText("")
                viewModel.apply {
                    postComment(myComment)
                }
                 //succ on prog
                //binding.prog.isVisible=false //


            }
        }




    }


}



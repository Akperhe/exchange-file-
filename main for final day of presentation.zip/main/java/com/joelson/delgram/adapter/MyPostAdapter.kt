package com.smith.contactapp.adapter


import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView

import android.annotation.SuppressLint
import android.content.Context
import android.media.MediaPlayer
import android.util.Log
import android.widget.Toast
import com.bumptech.glide.Glide
import com.joelson.delgram.Application
import com.joelson.delgram.R
import com.joelson.delgram.databinding.MyPostItemBinding
import com.joelson.delgram.databinding.PostItemBinding
import com.joelson.delgram.fragments.HomeFragment
import com.joelson.delgram.model.DataX
import com.joelson.delgram.model2.Data

import java.text.ParseException
import java.text.SimpleDateFormat
import java.util.*

class MyPostAdapter(
    var datas: List<Data>,
    var context: Context
    // var clickerLiker: (DataX) -> Unit,
    //var clickerLiker2: (DataX) -> Unit

) :

    RecyclerView.Adapter<MyPostAdapter.MyPostViewHolder>() {

    inner class MyPostViewHolder(private val binding: MyPostItemBinding) :
        RecyclerView.ViewHolder(binding.root) {

        fun bind(data: Data) {
           // val time = convertISOTimeToDate(data.dateCreated)

            binding.apply {
                try {

                    Glide.with(imageUpload).load(data.Image_url[0].toString()).into(binding.imageUpload)
                    Glide.with(profileImage).load(data.userid.profilePicture).into(binding.profileImage)
                    username.text = data.userid.userName
                    location.text = Application.sessionManager.location.toString() //data.userid.location
                    commentText.text = data.title

                    var like = data.noOflikes
                    likeTextCount.text = like.toString()
                    userWhoLiked.text= data.userid.userName
                    dateText.text = data.dateCreated
                    Glide.with(likedProfileImage).load(data.userid.profilePicture).into(binding.likedProfileImage)
                    //the above suppos be user who like which is not in back end varable
                    //favourite.setImageResource(R.drawable.ic_add_to_favorite2)
                    Log.i("ViewModel Response", "rerunning")
                    var booler =  true
                    favourite.setOnClickListener {

                        val mediaPlayer : MediaPlayer = MediaPlayer.create(context,R.raw.click)
                        mediaPlayer.start()
                        //clickerLiker(data)
                        run{
                            Log.i("ViewModel Response", "rerunning in listener insider")
                            //var booler: Boolean = true//clickerLiker(data)
                            if (booler == true) {

                                Log.i("ViewModel Response", "rerunning in listener if")
                                favourite.setImageResource(R.drawable.ic_add_to_favorite2)
                                Toast.makeText(context, "Added to favourite", Toast.LENGTH_SHORT).show()
                                booler = false
                            } else {
                                Log.i("ViewModel Response", "rerunning in listener else")
                                favourite.setImageResource(R.drawable.ic_add_to_favorite)
                                Toast.makeText(context, "Removed from favourite", Toast.LENGTH_SHORT).show()
                                booler = true
                            }
                        }

                    }

                    var booler1 =  true
                    love.setOnClickListener {
                        //clickerLiker(data)
                        //mp3 sound
                        val mediaPlayer : MediaPlayer = MediaPlayer.create(context,R.raw.click)
                        mediaPlayer.start()
                        //mp3 sound
                        run{
                            Log.i("ViewModel Response", "rerunning in listener insider")
                            //var booler: Boolean = true//clickerLiker(data)
                            if (booler1 == true) {

                                Log.i("ViewModel Response", "rerunning in listener if liked")
                                love.setImageResource(R.drawable.ic_like_or_love)

                                likeTextCount.setText((likeTextCount.text.toString().toInt()+ 1).toString())

                                Toast.makeText(context, "Liked", Toast.LENGTH_SHORT).show()
                                booler1 = false
                            } else {
                                Log.i("ViewModel Response", "rerunning in listener else unliked")
                                love.setImageResource(R.drawable.ic_like_or_love2)
                                likeTextCount.setText((likeTextCount.text.toString().toInt() - 1).toString())
                                Toast.makeText(context, "Unliked", Toast.LENGTH_SHORT).show()
                                booler1 = true
                            }
                        }
                    }
                    //root.setOnClickListener { data?.let {
                    // clicker(it)
                    // } }


                } catch (e: Exception){
                    0
                }

            }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MyPostViewHolder {
        val binding = MyPostItemBinding.inflate(LayoutInflater.from(parent.context),parent,false)
        return MyPostViewHolder(binding)
    }

    override fun onBindViewHolder(holder: MyPostViewHolder, position: Int) {
        holder.bind(datas[position])
    }

    override fun getItemCount() = datas.size

    override fun onAttachedToRecyclerView(recyclerView: RecyclerView) {
        super.onAttachedToRecyclerView(recyclerView)

    }

    @SuppressLint("SimpleDateFormat")
    fun convertISOTimeToDate(isoTime: String): String? {
        val sdf = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS")
        var convertedDate: Date? = null
        var formattedDate: String? = null
        try {
            convertedDate = sdf.parse(isoTime)
            formattedDate = SimpleDateFormat("dd-MM-yy").format(convertedDate!!)
        } catch (e: ParseException) {
            e.printStackTrace()
        }
        return formattedDate
    }

}
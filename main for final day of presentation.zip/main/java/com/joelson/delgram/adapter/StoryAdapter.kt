package com.smith.contactapp.adapter


import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView

import android.annotation.SuppressLint
import android.content.Intent
import android.util.Log
import android.widget.Toast
import com.bumptech.glide.Glide
import com.joelson.delgram.ChatAreActivity
import com.joelson.delgram.R
import com.joelson.delgram.databinding.ChatItemBinding
import com.joelson.delgram.databinding.PostItemBinding
import com.joelson.delgram.databinding.StoriesBinding
import com.joelson.delgram.fragments.HomeFragment
import com.joelson.delgram.model.DataX

import java.text.ParseException
import java.text.SimpleDateFormat
import java.util.*

class StoryAdapter(
    var datas: List<DataX>,

) :

    RecyclerView.Adapter<StoryAdapter.StoryViewHolder>() {

    inner class StoryViewHolder(private val binding: StoriesBinding

    ) :
        RecyclerView.ViewHolder(binding.root) {

        fun bind(data: DataX) {


            binding.apply {
                try {

                    Glide.with(storieThumbnail).load(data.Image_url[0].toString()).into(binding.storieThumbnail)
                    firstName.text = data.userid.userName

                    //the above suppos be user who like which is not in back end varable
                    //favourite.setImageResource(R.drawable.ic_add_to_favorite2)
                    //root.setOnClickListener { data?.let {
                       // clicker(it)
                   // } }

                } catch (e: Exception){
                    0
                }

            }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): StoryViewHolder {
        val binding = StoriesBinding.inflate(LayoutInflater.from(parent.context),parent,false)
        return StoryViewHolder(binding)
    }

    override fun onBindViewHolder(holder: StoryViewHolder, position: Int) {
        holder.bind(datas[position])
    }

    override fun getItemCount() = datas.size

    override fun onAttachedToRecyclerView(recyclerView: RecyclerView) {
        super.onAttachedToRecyclerView(recyclerView)

    }

}
package com.smith.contactapp.adapter


import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView

import android.annotation.SuppressLint
import android.content.Intent
import android.util.Log
import android.widget.Toast
import com.bumptech.glide.Glide
import com.joelson.delgram.ChatAreActivity
import com.joelson.delgram.R
import com.joelson.delgram.databinding.ChatItemBinding
import com.joelson.delgram.databinding.CommentsItemBinding
import com.joelson.delgram.databinding.PostItemBinding
import com.joelson.delgram.fragments.HomeFragment
import com.joelson.delgram.model2.DataX

import java.text.ParseException
import java.text.SimpleDateFormat
import java.util.*

class CommentsAdapter(
    var datas: List<DataX>
    //var context: HomeFragment
    // var clickerLiker: (DataX) -> Unit,
    //var clickerLiker2: (DataX) -> Unit

) :

    RecyclerView.Adapter<CommentsAdapter.CommentsViewHolder>() {

    inner class CommentsViewHolder(private val binding: CommentsItemBinding

    ) :
        RecyclerView.ViewHolder(binding.root) {

        fun bind(data: DataX) {
            //val time = convertISOTimeToDate(data.dateCreated)

            binding.apply {
                try {

                    Glide.with(photo).load(data.user_id.profilePicture).into(binding.photo)
                    text.text = data.commentText



                } catch (e: Exception){
                    0
                }

            }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): CommentsViewHolder {
        val binding = CommentsItemBinding.inflate(LayoutInflater.from(parent.context),parent,false)
        return CommentsViewHolder(binding)
    }

    override fun onBindViewHolder(holder: CommentsViewHolder, position: Int) {
        holder.bind(datas[position])
    }

    override fun getItemCount() = datas.size

    override fun onAttachedToRecyclerView(recyclerView: RecyclerView) {
        super.onAttachedToRecyclerView(recyclerView)

    }

    @SuppressLint("SimpleDateFormat")
    fun convertISOTimeToDate(isoTime: String): String? {
        val sdf = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS")
        var convertedDate: Date? = null
        var formattedDate: String? = null
        try {
            convertedDate = sdf.parse(isoTime)
            formattedDate = SimpleDateFormat("dd-MM-yy").format(convertedDate!!)
        } catch (e: ParseException) {
            e.printStackTrace()
        }
        return formattedDate
    }

}
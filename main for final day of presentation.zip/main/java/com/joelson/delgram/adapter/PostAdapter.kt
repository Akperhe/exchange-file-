package com.smith.contactapp.adapter


import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView

import android.annotation.SuppressLint
import android.content.Intent
import android.media.MediaPlayer
import android.net.Uri
import android.util.Log
import android.widget.Toast
import androidx.core.content.ContextCompat.startActivity
import com.bumptech.glide.Glide
import com.joelson.delgram.Application
import com.joelson.delgram.CommentActivity
import com.joelson.delgram.MainActivity
import com.joelson.delgram.R
import com.joelson.delgram.databinding.PostItemBinding
import com.joelson.delgram.fragments.HomeFragment
import com.joelson.delgram.model.DataX

import java.text.ParseException
import java.text.SimpleDateFormat
import java.util.*

class PostAdapter(
    var datas: List<DataX>,
    var context: HomeFragment
   // var clickerLiker: (DataX) -> Unit,
    //var clickerLiker2: (DataX) -> Unit

) :

    RecyclerView.Adapter<PostAdapter.PostViewHolder>() {

    inner class PostViewHolder(private val binding: PostItemBinding) :
        RecyclerView.ViewHolder(binding.root) {
        var no = 2
        fun bind(data: DataX) {
//            val time = convertISOTimeToDate(data.dateCreated)

            binding.apply {
                try {

                    Glide.with(imageUpload).load(data.Image_url[0].toString()).into(binding.imageUpload)
                    Glide.with(profileImage).load(data.userid.profilePicture).into(binding.profileImage)
                    username.text = data.userid.userName
                    location.text = data.userid.location
                    commentText.text = data.title

                    var like = data.noOflikes
                    likeTextCount.text = like.toString()
                    userWhoLiked.text= data.userid.userName
                    dateText.text = data.dateCreated.toString()
                    Log.i("Datecreated", data.dateCreated.toString())
                    Glide.with(likedProfileImage).load(data.userid.profilePicture).into(binding.likedProfileImage)
                    //the above suppos be user who like which is not in back end varable
                    //favourite.setImageResource(R.drawable.ic_add_to_favorite2)
                    Log.i("ViewModel Response", "rerunning")
                    var booler =  true
                    favourite.setOnClickListener {
                        //clickerLiker(data)
                        val mediaPlayer : MediaPlayer = MediaPlayer.create(context.requireContext(),R.raw.click)
                        mediaPlayer.start()
                        run{
                            Log.i("ViewModel Response", "rerunning in listener insider")
                            //var booler: Boolean = true//clickerLiker(data)
                            if (booler == true) {

                                Log.i("ViewModel Response", "rerunning in listener if")
                                favourite.setImageResource(R.drawable.ic_add_to_favorite2)
                                Toast.makeText(context.requireContext(), "Added to favourite", Toast.LENGTH_SHORT).show()
                                booler = false
                            } else {
                                Log.i("ViewModel Response", "rerunning in listener else")
                                favourite.setImageResource(R.drawable.ic_add_to_favorite)
                                Toast.makeText(context.requireContext(), "Removed from favourite", Toast.LENGTH_SHORT).show()
                                booler = true
                            }
                        }

                    }

                    var booler1 =  true
                    love.setOnClickListener {

                        val mediaPlayer : MediaPlayer = MediaPlayer.create(context.requireContext(),R.raw.click)
                        mediaPlayer.start()
                        //clickerLiker(data)
                        run{
                            Log.i("ViewModel Response", "rerunning in listener insider")
                            //var booler: Boolean = true//clickerLiker(data)
                            if (booler1 == true) {

                                Log.i("ViewModel Response", "rerunning in listener if liked")
                                love.setImageResource(R.drawable.ic_like_or_love)

                                likeTextCount.setText((likeTextCount.text.toString().toInt()+ 1).toString())

                                Toast.makeText(context.requireContext(), "Liked", Toast.LENGTH_SHORT).show()
                                booler1 = false
                            } else {
                                Log.i("ViewModel Response", "rerunning in listener else unliked")
                                love.setImageResource(R.drawable.ic_like_or_love2)
                                likeTextCount.setText((likeTextCount.text.toString().toInt() - 1).toString())
                                Toast.makeText(context.requireContext(), "Unliked", Toast.LENGTH_SHORT).show()
                                booler1 = true
                            }
                        }
                    }
                      var postId : String = data._id.toString() //id of the post -id or id
                    comment.setOnClickListener {

                        val intent: Intent = Intent(context.requireContext(), CommentActivity::class.java)
                        intent.putExtra("postId", postId.toString())
                        Log.i("PostID", postId.toString())

                        context.startActivity(intent)

                    }

                    call.setOnClickListener {

                        var phoneNumber = "08036844238"
                        no = no + 1
                        val intent: Intent = Intent(Intent.ACTION_DIAL)
                        run {
                            if (no % 2 == 0) {
                                intent.setData(Uri.parse("tel:" + phoneNumber.toString()))
                                context.startActivity(intent)
                            }
                            if (no % 2 == 1) {
                                Toast.makeText(
                                    context.requireContext(),
                                    "Double click to call this contact",
                                    Toast.LENGTH_SHORT
                                ).show()

                            }

                        }
                    }


                    //root.setOnClickListener { data?.let {
                       // clicker(it)
                   // } }


                } catch (e: Exception){
                    0
                }

            }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): PostViewHolder {
        val binding = PostItemBinding.inflate(LayoutInflater.from(parent.context),parent,false)
        return PostViewHolder(binding)
    }

    override fun onBindViewHolder(holder: PostViewHolder, position: Int) {
        holder.bind(datas[position])
    }

    override fun getItemCount() = datas.size

    override fun onAttachedToRecyclerView(recyclerView: RecyclerView) {
        super.onAttachedToRecyclerView(recyclerView)

    }

    @SuppressLint("SimpleDateFormat")
    fun convertISOTimeToDate(isoTime: String): String? {
        val sdf = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS")
        var convertedDate: Date? = null
        var formattedDate: String? = null
        try {
            convertedDate = sdf.parse(isoTime)
            formattedDate = SimpleDateFormat("dd-MM-yy").format(convertedDate!!)
        } catch (e: ParseException) {
            e.printStackTrace()
        }
        return formattedDate
    }

}
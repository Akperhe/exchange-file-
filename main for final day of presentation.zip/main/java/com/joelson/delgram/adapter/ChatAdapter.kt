package com.smith.contactapp.adapter


import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView

import android.annotation.SuppressLint
import android.content.Intent
import android.util.Log
import android.widget.Toast
import com.bumptech.glide.Glide
import com.joelson.delgram.ChatAreActivity
import com.joelson.delgram.R
import com.joelson.delgram.databinding.ChatItemBinding
import com.joelson.delgram.databinding.PostItemBinding
import com.joelson.delgram.fragments.HomeFragment
import com.joelson.delgram.model.DataX

import java.text.ParseException
import java.text.SimpleDateFormat
import java.util.*

class ChatAdapter(
    var datas: List<DataX>,
    //var context: HomeFragment
   // var clickerLiker: (DataX) -> Unit,
    //var clickerLiker2: (DataX) -> Unit

) :

    RecyclerView.Adapter<ChatAdapter.PostViewHolder>() {

    inner class PostViewHolder(private val binding: ChatItemBinding

    ) :
        RecyclerView.ViewHolder(binding.root) {

        fun bind(data: DataX) {
//            val time = convertISOTimeToDate(data.dateCreated)

            binding.apply {
                try {

                    Glide.with(imageicon).load(data.userid.profilePicture).into(binding.imageicon)
                    profileName.text = data.userid.userName
                    textsent.text = data.title
                    binding.root.setOnClickListener {
                        val context = binding.root.context
                        val intent: Intent = Intent(context, ChatAreActivity::class.java)
                        context.startActivity(intent)
                    }
                    //the above suppos be user who like which is not in back end varable
                    //favourite.setImageResource(R.drawable.ic_add_to_favorite2)
                    //root.setOnClickListener { data?.let {
                       // clicker(it)
                   // } }

                } catch (e: Exception){
                    0
                }

            }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): PostViewHolder {
        val binding = ChatItemBinding.inflate(LayoutInflater.from(parent.context),parent,false)
        return PostViewHolder(binding)
    }

    override fun onBindViewHolder(holder: PostViewHolder, position: Int) {
        holder.bind(datas[position])
    }

    override fun getItemCount() = datas.size

    override fun onAttachedToRecyclerView(recyclerView: RecyclerView) {
        super.onAttachedToRecyclerView(recyclerView)

    }

    @SuppressLint("SimpleDateFormat")
    fun convertISOTimeToDate(isoTime: String): String? {
        val sdf = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS")
        var convertedDate: Date? = null
        var formattedDate: String? = null
        try {
            convertedDate = sdf.parse(isoTime)
            formattedDate = SimpleDateFormat("dd-MM-yy").format(convertedDate!!)
        } catch (e: ParseException) {
            e.printStackTrace()
        }
        return formattedDate
    }

}
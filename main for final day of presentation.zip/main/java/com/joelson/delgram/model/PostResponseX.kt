package com.joelson.delgram.model

data class PostResponseX(
    val Image_url: List<String>,
    val __v: Int,
    val _id: String,
    val dateCreated: String,
    val id: String,
    val noOflikes: Int,
    val stack: String,
    val title: String,
    val userid: String
)
package com.joelson.delgram.model

data class LoginModel(
    val userName: String,
    val password: String
)



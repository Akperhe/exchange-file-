package com.joelson.delgram.model

data class Userid(
    val location: String,
    val profilePicture: String,
    val userName: String
)
package com.joelson.delgram.model

data class ResponseFromUpdateProfile //was named Data before from UpdateProfileDetailResponse
    (
    val __v: Int,
    val _id: String,
    val bio: String,
    val dateCreated: String,
    val email: String,
    val firstName: String,
    val gender: String,
    val isOnline: Boolean,
    val lastName: String,
    val location: String,
    val password: String,
    val phoneNumber: String,
    val profilePicture: String,
    val stack: String,
    val userName: String,
    val website: String
)
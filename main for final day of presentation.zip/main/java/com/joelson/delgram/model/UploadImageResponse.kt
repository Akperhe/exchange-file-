package com.joelson.delgram.model

data class UploadImageResponse(
    val `data`: Payload,
    val message: String
)
data class Payload( //here was Data before but was change here to Payload becos of Data was was already define in data class however two or more can
                    // use same class response, in th sense they have to select var in the class
    val __v: Int,
    val _id: String,
    val dateCreated: String,
    val email: String,
    val firstName: String,
    val isOnline: Boolean,
    val lastName: String,
    val password: String,
    val phoneNumber: String,
    val profilePicture: String,
    val stack: String,
    val userName: String,
    val bio : String,
    val location : String,
    val gender : String,
    val website : String
)
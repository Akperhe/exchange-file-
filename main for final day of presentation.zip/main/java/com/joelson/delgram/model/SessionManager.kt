package com.joelson.delgram.model

import com.joelson.delgram.R
import android.content.Context
import android.content.SharedPreferences

class SessionManager (context: Context) {
    private var prefs: SharedPreferences = context.getSharedPreferences(context.getString(R.string.app_name), Context.MODE_PRIVATE)

    companion object {
        private const val FIRST_NAME = "first_name"
        private const val LAST_NAME =  "last_name"
        private const val USER_NAME =  "user_name"
        private const val EMAIL =  "email"
        private const val ONLINE =  "isOnline"
        private const val PHONE_NUMBER =  "phone_number"
        private const val STACK =  "stack"
        private const val TOKEN =  "token"
        private const val SIGNED_IN =  "signed_in"
        private const val WEBSITE =  "website"
        private const val BIO =  "bio"
        private const val GENDER =  "gender"
        private const val PHOTO =  "photo"
        private const val ID =  "id"
        private const val USERID =  "userId"
        private const val LOCATION =  "location"
        private const val POST_ID = "postId"
    }

    /***************** FIRST_NAME *****************/

    var firstName :String?
        get() {
            return prefs.getString(FIRST_NAME, null)
        }
        set(value) {
            val editor = prefs.edit()
            editor.putString(FIRST_NAME, value)
            editor.apply()
        }

    /***************** LAST_NAME *****************/

    var lastName: String?
        get() {
            return prefs.getString(LAST_NAME, null)
        }
        set(value) {
            val editor = prefs.edit()
            editor.putString(LAST_NAME, value)
            editor.apply()
        }

    /***************** USER_NAME *****************/

    var userName: String?
        get() {
            return prefs.getString(USER_NAME, null)
        }
        set(value) {
            val editor = prefs.edit()
            editor.putString(USER_NAME, value)
            editor.apply()
        }

    /***************** EMAIL *****************/

    var email: String?
        get() {
            return prefs.getString(EMAIL, null)
        }
        set(value) {
            val editor = prefs.edit()
            editor.putString(EMAIL, value)
            editor.apply()
        }

    /***************** ONLINE *****************/

    var isOnline :Boolean
        get() {
            return prefs.getBoolean(ONLINE, false)
        }
        set(value) {
            val editor = prefs.edit()
            editor.putBoolean(ONLINE, value)
            editor.apply()
        }

    /***************** PHONE_NUMBER *****************/

    var phoneNumber :String?
        get() {
            return prefs.getString(PHONE_NUMBER, null)
        }
        set(value) {
            val editor = prefs.edit()
            editor.putString(PHONE_NUMBER, value)
            editor.apply()
        }

    /***************** STACK *****************/

    var stack :String?
        get() {
            return prefs.getString(STACK, null)
        }
        set(value) {
            val editor = prefs.edit()
            editor.putString(STACK, value)
            editor.apply()
        }


    /***************** TOKEN *****************/

    var token :String?
        get() {
            return prefs.getString(TOKEN, null)
        }
        set(value) {
            val editor = prefs.edit()
            editor.putString(TOKEN, value)
            editor.apply()
        }

    /***************** SIGNED_IN *****************/

    var isUserSignedIn :Boolean
        get() {
            return prefs.getBoolean(SIGNED_IN, false)
        }
        set(value) {
            val editor = prefs.edit()
            editor.putBoolean(SIGNED_IN, value)
            editor.apply()
        }

    /***************** WEBSITE *****************/

    var website :String?
        get() {
            return prefs.getString(WEBSITE, null)
        }
        set(value) {
            val editor = prefs.edit()
            editor.putString(WEBSITE, value)
            editor.apply()
        }

    var bio :String?
        get() {
            return prefs.getString(BIO, null)
        }
        set(value) {
            val editor = prefs.edit()
            editor.putString(BIO, value)
            editor.apply()
        }

    var gender :String?
        get() {
            return prefs.getString(GENDER, null)
        }
        set(value) {
            val editor = prefs.edit()
            editor.putString(GENDER, value)
            editor.apply()
        }

    var profilePicUrl :String?
        get() {
            return prefs.getString(PHOTO, null)
        }
        set(value) {
            val editor = prefs.edit()
            editor.putString(PHOTO, value)
            editor.apply()
        }

    var id :String?
        get() {
            return prefs.getString(ID, null)
        }
        set(value) {
            val editor = prefs.edit()
            editor.putString(ID, value)
            editor.apply()
        }

    var userId :String?
        get() {
            return prefs.getString(USERID, null)
        }
        set(value) {
            val editor = prefs.edit()
            editor.putString(USERID, value)
            editor.apply()
        }


    var location :String?
        get() {
            return prefs.getString(LOCATION, null)
        }
        set(value) {
            val editor = prefs.edit()
            editor.putString(LOCATION, value)
            editor.apply()
        }

    var postId :String?
        get() {
            return prefs.getString(POST_ID, null)
        }
        set(value) {
            val editor = prefs.edit()
            editor.putString(POST_ID, value)
            editor.apply()
        }
}
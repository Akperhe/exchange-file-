package com.joelson.delgram.model

data class UpdateProfileDetailModel(
    val email: String,
    val firstName: String,
    val lastName: String,
    val gender: String,
    val phoneNumber: String,
    val stack: String,
    val bio: String,
    val website : String,
    val location : String
)
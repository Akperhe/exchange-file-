package com.joelson.delgram.model

data class UpdateProfileDetailResponse(
    val `data`: ResponseFromUpdateProfile
)
package com.joelson.delgram.model

data class LoginRequest (
    val userName: String,
    val password: String
        )



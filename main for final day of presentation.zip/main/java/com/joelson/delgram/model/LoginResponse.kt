package com.joelson.delgram.model

data class LoginResponse(
    val msg: String,
    val token: String,
    val user: User
)

data class User(
    val __v: Int,
    val _id: String,
    val dateCreated: String,
    val email: String,
    val firstName: String,
    val lastName: String,
    val isOnline: Boolean,
    val password: String,
    val phoneNumber: String,
    val stack: String,
    val userName: String,
    val profilePicture : String,
    val location : String//update
)

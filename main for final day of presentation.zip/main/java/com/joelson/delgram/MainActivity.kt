package com.joelson.delgram

import android.content.Intent
import android.net.Uri
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.provider.MediaStore
import android.util.Log
import android.view.LayoutInflater
import android.view.MenuItem
import android.view.View
import android.widget.LinearLayout
import android.widget.Toast
import androidx.activity.viewModels
import androidx.appcompat.app.ActionBarDrawerToggle
import androidx.core.view.GravityCompat
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import com.bumptech.glide.Glide
import com.google.android.material.bottomnavigation.BottomNavigationView
import com.google.android.material.bottomsheet.BottomSheetDialog
import com.joelson.delgram.databinding.*
import com.joelson.delgram.fragments.ChatFragment
import com.joelson.delgram.fragments.HomeFragment
import com.joelson.delgram.fragments.ProfileFragment
import com.joelson.delgram.fragments.SearchFragment
import com.joelson.delgram.viewModel.EditProfileViewModel
import com.joelson.delgram.viewModel.MainActivityViewModel
import com.joelson.delgram.viewModel.PostViewModel
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.MultipartBody


class MainActivity : AppCompatActivity() {
    private  var mBinding: ActivityMainBinding? = null
    private lateinit var mBinding2: PostItemBinding
    private  lateinit var  bottomSheet: LayoutBottomSearchBinding
    private  lateinit var  navHeaderBinding: NavHeaderBinding
    private lateinit var bottomSheet1: LayoutBottomAddPostBinding
    private var imageURI: Uri? = null
    var PICK_PHOTO_CODE = 1046
    val viewModel : PostViewModel by viewModels<PostViewModel>()

    private val onNavigationItemSelectedListener =
          BottomNavigationView.OnNavigationItemSelectedListener { item ->
              when (item.itemId) {

                  R.id.nav_home -> {
                      moveToFragment(HomeFragment())
                      return@OnNavigationItemSelectedListener true
                  }
                  R.id.nav_search -> {
                      bottomSheet = LayoutBottomSearchBinding.inflate(layoutInflater)
                      val bottomSheetDialog = BottomSheetDialog(this)
                      bottomSheet = LayoutBottomSearchBinding.inflate(layoutInflater)
                      bottomSheetDialog.setContentView(bottomSheet.root)
                      bottomSheetDialog.show()


                      //moveToFragment(SearchFragment())
                      return@OnNavigationItemSelectedListener true
                  }
                  R.id.nav_add -> {
                     // item.isChecked = false
                      //startActivity(Intent(this@MainActivity, AddPostActivity::class.java))
                      bottomSheet1 = LayoutBottomAddPostBinding.inflate(layoutInflater)



                      val bottomSheetDialog = BottomSheetDialog(this)
                      bottomSheet1 = LayoutBottomAddPostBinding.inflate(layoutInflater)
                      bottomSheetDialog.setContentView(bottomSheet1.root)
                      bottomSheetDialog.show()

                      //add
                      bottomSheet1.addPostPhotos.setOnClickListener {

/*
                          fun onClickPost(v: View?) {
                              if (v != null) {
                                  when (v.id) {
                                      R.id.iv_add_profile_image -> {
                                          onPickPhoto(v)
                                      }
                                  }
                              }
                          } */
                          // fun onPickPhoto(view: View) {
                          val intent = Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI)
                          if (intent.resolveActivity(packageManager) != null) {
                              startActivityForResult(intent, PICK_PHOTO_CODE)
                          }
                          // }

                       /*  fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
                              if (data != null && requestCode == PICK_PHOTO_CODE && resultCode == RESULT_OK) {
                                  Toast.makeText(this, "Image Succefful handled!", Toast.LENGTH_LONG ).show()
                                  /*
                                   data.data?.apply {
                                       imageURI = this
                                       Glide.with(this@MainActivity)
                                           .load(this)
                                           .centerCrop() //i added this line from the previous
                                           .into(mBinding.ivProfileImage)
                                   }
                                   */
                              }else Toast.makeText(this, "Failed to get image!", Toast.LENGTH_LONG ).show()
                              super.onActivityResult(requestCode, resultCode, data)
                          } */
                      }
                      //add

                      bottomSheet1.postIt.setOnClickListener {



                          val title =bottomSheet1.addPostText.text.toString()
                          if( imageURI != null){

                              val image = InputStreamRequestBody("multipart/form-data".toMediaTypeOrNull(), contentResolver, imageURI!!)

                              Log.i("Title" , title)
                              val requestBody: MultipartBody = MultipartBody.Builder()
                                  .setType(MultipartBody.FORM)
                                  .addFormDataPart("title", title)
                                  .addFormDataPart("images", "images", image)
                                  .build()

                              viewModel.makeAPost(requestBody)
                             // viewModel.isLoading.observe(this){}
                              Toast.makeText(applicationContext, "Posted", Toast.LENGTH_SHORT).show()
                              bottomSheet1.addPostText.setText("")
                              bottomSheetDialog.dismiss()
                             // val intent: Intent = Intent(this, MainActivity::class.java)
                              //intent.putExtra("postId", postId.toString())
                              //Log.i("PostID", postId.toString())

                            //  startActivity(intent)
                              //mBinding?.prog?.visibility = View.VISIBLE

                          } else {
                              Toast.makeText(applicationContext, "Please select an image with a title", Toast.LENGTH_SHORT).show()

                          }

                          viewModel.isLoading.observe(this, {
                              //if(it) mBinding?.prog?.visibility = View.VISIBLE else  mBinding?.prog?.visibility = View.GONE
                          })

                      }
                      return@OnNavigationItemSelectedListener true
                  }
                  R.id.nav_send -> {

                      item.isChecked = false
                      startActivity(Intent(this@MainActivity, ChatActivity::class.java))

                      //moveToFragment(ChatFragment())
                      return@OnNavigationItemSelectedListener true
                  }
                  R.id.nav_profile -> {

                      item.isChecked = false
                      Log.i("innFRP", Application.sessionManager.id.toString())
                      Log.i("innFRP", Application.sessionManager.firstName.toString())

                      startActivity(Intent(this@MainActivity, ProfileActivity::class.java))
                      //moveToFragment(ProfileFragment())
                      return@OnNavigationItemSelectedListener true
                  }
              }
              false
          }

    var drawer = mBinding?.drawer
    override fun onCreate(savedInstanceState: Bundle?)

    {
        super.onCreate(savedInstanceState)
        mBinding = ActivityMainBinding.inflate(layoutInflater)
        mBinding2 = PostItemBinding.inflate(layoutInflater)
        bottomSheet = LayoutBottomSearchBinding.inflate(layoutInflater)
        bottomSheet1 = LayoutBottomAddPostBinding.inflate(layoutInflater)
        navHeaderBinding = NavHeaderBinding.inflate(layoutInflater)

        setContentView(mBinding?.root)


        //setSupportActionBar(mBinding.toolbar)
        Log.i("innMain", Application.sessionManager.id.toString())
        drawer = mBinding?.drawer
        val drawerToggle = ActionBarDrawerToggle(this, drawer, R.string.open, R.string.close)
        drawer?.addDrawerListener(drawerToggle)
        drawerToggle.syncState()
        drawerToggle.isDrawerIndicatorEnabled =false
        drawerToggle.setHomeAsUpIndicator(R.drawable.ic_menu_options)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)


        if (inCreate) {
            moveToFragment(ProfileFragment())
            inCreate = false
        } else {
            moveToFragment(HomeFragment())
        }
        mBinding?.bottomNavView?.setOnNavigationItemSelectedListener (onNavigationItemSelectedListener)

        mBinding?.dotMenu?.setOnClickListener {

            openCloseNavigationDrawer()
            navHeaderBinding.apply {
                Glide.with(ivProfileImage).load(Application.sessionManager.profilePicUrl.toString())
                    .centerCrop()
                    .into(navHeaderBinding.ivProfileImage)
                Log.i("Nav", "Loaded")
                usernameId.setText(Application.sessionManager.firstName.toString())
                Log.i("Nav", "Loaded")
                emailId.setText(Application.sessionManager.email.toString())
            }

        }



//drawer listener
        mBinding?.navigationView?.setNavigationItemSelectedListener {
            when(it.itemId){
                R.id.nav_logout -> {
                    Application.sessionManager.isUserSignedIn = false
                    Application.sessionManager.id = null
                    Application.sessionManager.userName = null
                    Application.sessionManager.profilePicUrl = null
                    Application.sessionManager.bio = null
                    Application.sessionManager.phoneNumber = null
                    Application.sessionManager.website = null
                    Application.sessionManager.firstName = null
                    Application.sessionManager.lastName = null
                    Application.sessionManager.email =null
                    Application.sessionManager.gender =null
                    Application.sessionManager.isOnline=false
                    Application.sessionManager.stack=null
                    Application.sessionManager.token = null
                    Application.sessionManager.userId = null
                    val intent: Intent = Intent(this, LoginActivity::class.java)
                    startActivity(intent)

                }
            R.id.nav_send ->  {
                var phoneNumber = "08036844238"
                val intent: Intent = Intent(Intent.ACTION_DIAL)
                intent.setData(Uri.parse("tel:" + phoneNumber.toString()))
                startActivity(intent)
            }
            }
            true
        }
        //drawer
        mBinding?.fhNotification?.setOnClickListener {
            Toast.makeText(this, "No Notfication Yet", Toast.LENGTH_LONG ).show()
        }

    }

//my code to sele image
override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
    if (data != null && requestCode == PICK_PHOTO_CODE && resultCode == RESULT_OK) {
        Toast.makeText(this, "Photo handled Successffuly", Toast.LENGTH_LONG ).show()
        data.data?.apply {
           imageURI = this
            Glide.with(this@MainActivity)
                .load(this)
                .centerCrop() //i added this line from the previous
                .into(bottomSheet1.uploadedImage)
        }
    }else Toast.makeText(this, "Failed to get image!", Toast.LENGTH_LONG ).show()
    super.onActivityResult(requestCode, resultCode, data)
}
//my code to sele image

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            android.R.id.home -> {
                var drawer = mBinding?.drawer
                drawer?.openDrawer(GravityCompat.START)
                Toast.makeText(this, "Failed to get image!", Toast.LENGTH_LONG ).show()
                true
            }
            else -> super.onOptionsItemSelected(item)
        }
    }


    private fun moveToFragment(fragment: Fragment) {
        val fragmentTrans = supportFragmentManager.beginTransaction()
        mBinding?.fragmentContainer?.let { fragmentTrans.replace(it.id, fragment) }
        fragmentTrans.commit()

    }



    companion object {
        var inCreate = false
        var moveTo = false
    }

    fun openCloseNavigationDrawer() {

        if (drawer?.isDrawerOpen(GravityCompat.START) == true){
            drawer?.closeDrawer(GravityCompat.START)
        } else {
            drawer?.openDrawer(GravityCompat.START)
        }
    }
}


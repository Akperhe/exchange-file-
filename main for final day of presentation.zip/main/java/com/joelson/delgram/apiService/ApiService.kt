package com.joelson.delgram.apiService

import com.joelson.delgram.model.*
import com.joelson.delgram.model2.CommentResponse
import com.joelson.delgram.model2.MyCommentModel
import com.joelson.delgram.model2.MyCommentResponse
import com.joelson.delgram.model2.MyPostResponse
import okhttp3.MultipartBody
import okhttp3.RequestBody

import retrofit2.Response
import retrofit2.http.*

interface ApiService {

    @POST("api/users/signup")
    suspend fun signUpUser (@Body newUser: SignupModel): Response<SignupResponse>

    @POST ("api/users/login")
    suspend fun loginUser (@Body login: LoginModel): Response<LoginResponse>

    @GET("api/post/allpost")
    suspend fun getAllPost(): PostResponse

    @POST ("api/users/{id}")
    suspend fun uploadProfilePic (@Path("id") user :String, @Body payload: RequestBody): Response<UploadImageResponse>

    @PUT ("api/users/{id}")
    suspend fun updateProfileDetails (@Path("id") user :String, @Body userUpdateProfileDetails: UpdateProfileDetailModel): Response<UpdateProfileDetailResponse>
   // api/post/new
    @POST ("api/post/new")
    suspend fun makeAPost (@Body payload: RequestBody) : Response<PostResponseX>

    @GET("api/post/userposts")
    suspend fun getAllMyPost(): MyPostResponse

    @GET("api/post/allcomment/{id}")
    suspend fun getAllComments(@Path("id") user :String): CommentResponse

    @POST ("api/post/{id}")
    suspend fun postComment (@Path("id") user :String, @Body postComment:MyCommentModel) : Response<MyCommentResponse>

}



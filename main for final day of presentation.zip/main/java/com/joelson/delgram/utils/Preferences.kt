package com.joelson.delgram.utils

import android.app.Activity
import android.content.Context
import android.content.SharedPreferences

class Preferences(private val activity: Activity) {
    private val sharedPref: SharedPreferences =
        activity.getSharedPreferences("delgram", Context.MODE_PRIVATE)

    fun saveId(id: String) {
        with(sharedPref.edit()) {
            putString("id", id)
            apply()
        }
    }

    fun saveToken(token: String) {
        with(sharedPref.edit()) {
            putString("token", token)
            apply()
        }
    }

    fun setIsLoggedIn(isLoggedIn: Boolean) {
        with(sharedPref.edit()) {
            putBoolean("logged_in", isLoggedIn)
            apply()
        }
    }

    fun setUserName(name: String){
        with(sharedPref.edit()){
            putString("name", name)
            apply()
        }
    }

    fun getIsLoggedIn() = sharedPref.getBoolean("logged_in", false)

    fun getId() = sharedPref.getString("id", null)
    fun getToken() = sharedPref.getString("token", null)
    fun getUserName() = sharedPref.getString("name", null)
}
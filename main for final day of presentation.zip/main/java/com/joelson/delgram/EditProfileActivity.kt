package com.joelson.delgram

import android.app.Dialog
import android.content.Intent
import android.net.Uri
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.provider.MediaStore
import android.util.Log
import android.view.View
import android.widget.Toast
import androidx.activity.viewModels
import com.bumptech.glide.Glide
import com.joelson.delgram.databinding.ActivityEditProfileBinding
import com.joelson.delgram.model.UpdateProfileDetailModel
import com.joelson.delgram.viewModel.EditProfileViewModel
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.MultipartBody
import java.util.*

class EditProfileActivity : AppCompatActivity(), View.OnClickListener {

    private lateinit var mBinding: ActivityEditProfileBinding
   // private var mImagePath: String = ""
   // private lateinit var mCustomListDialog: Dialog
    private var imageURI: Uri? = null
    val PICK_PHOTO_CODE = 1046
    val viewModel : EditProfileViewModel by viewModels<EditProfileViewModel>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        mBinding = ActivityEditProfileBinding.inflate(layoutInflater)
        setContentView(mBinding.root)

        //Log.i("Gliding", "loading")
        //Log.i("Gliding", Application.sessionManager.stack.toString())
        mBinding.firstName.setText("${Application.sessionManager.firstName.toString()}")
        mBinding.lastName.setText(Application.sessionManager.lastName.toString())
        mBinding.stackDropdown.setText(Application.sessionManager.stack.toString())
        mBinding.emailId.setText(Application.sessionManager.email.toString())
        mBinding.websiteId.setText(Application.sessionManager.website.toString())
        mBinding.bioId.setText(Application.sessionManager.bio.toString())
        mBinding.genderId.setText(Application.sessionManager.gender.toString())
        mBinding.phoneNumberId.setText(Application.sessionManager.phoneNumber.toString())
        mBinding.locationId.setText(Application.sessionManager.location.toString())

        if (Application.sessionManager.profilePicUrl.toString()=="null") {
            mBinding.ivProfileImage.setImageResource(R.drawable.profile)
        } else {
            mBinding.apply {
                Glide.with(ivProfileImage)
                    .load(Application.sessionManager.profilePicUrl.toString())
                    .into(mBinding.ivProfileImage)
            }
        }

       /*
        mBinding.apply {
            Glide.with(ivProfileImage).load(Application.sessionManager.profilePicUrl.toString())
                //.centerCrop()
                .into(mBinding.ivProfileImage)
        }

*/
        mBinding.backBtn.setOnClickListener {
            val intent: Intent = Intent(this, ProfileActivity::class.java)
            startActivity(intent)
        }
        Log.i("innEditP", Application.sessionManager.id.toString())
        Log.i("innEditP", Application.sessionManager.firstName.toString())
        mBinding.epDone.setOnClickListener(this)

        mBinding.epDone.setOnClickListener {
            if( imageURI != null){
                Log.i("enter", "loveimage")
                val image = InputStreamRequestBody("multipart/form-data".toMediaTypeOrNull(), contentResolver, imageURI!!)

                val requestBody: MultipartBody = MultipartBody.Builder()
                    .setType(MultipartBody.FORM)
                    .addFormDataPart("image", "image", image)
                    .build()

                viewModel.updateUserprofileImage(requestBody)
            }

            if(mBinding.firstName.text.toString()!=null && mBinding.lastName.text.toString()!=null){

                Log.i("enter", "lovedetail")
                val firstName = mBinding.firstName.text.toString()
                val lastName = mBinding.lastName.text.toString()
                val website = mBinding.websiteId.text.toString()
                val stack = mBinding.stackDropdown.text.toString()
                val bio = mBinding.bioId.text.toString()
                val email = mBinding.emailId.text.toString()
                val phone = mBinding.phoneNumberId.text.toString()
                val gender = mBinding.genderId.text.toString()
                //val userName = Application.sessionManager.userName.toString()
                val location = mBinding.locationId.text.toString()

                val requestBody = UpdateProfileDetailModel(email,firstName,lastName,gender,phone,stack,bio,website,location)

                viewModel.updateUserProfileDetails(requestBody)   // here you the viewModel has passed the id on retrofit call
            }

            // am adding my code for the second call now


        }

        viewModel.isLoading.observe(this, {
            if(it) mBinding.progressBar.visibility = View.VISIBLE else  mBinding.progressBar.visibility = View.GONE
        })
    }


    override fun onClick(v: View?) {
        if (v != null) {
            when (v.id) {
                R.id.iv_add_profile_image -> {
                    onPickPhoto(v)
                }
            }
        }
    }
    private fun onPickPhoto(view: View) {
        val intent = Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI)
        if (intent.resolveActivity(packageManager) != null) {
            startActivityForResult(intent, PICK_PHOTO_CODE)
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        if (data != null && requestCode == PICK_PHOTO_CODE && resultCode == RESULT_OK) {

            data.data?.apply {
                imageURI = this
                Glide.with(this@EditProfileActivity)
                    .load(this)
                    .centerCrop() //i added this line from the previous
                    .into(mBinding.ivProfileImage)
            }
        }else Toast.makeText(this, "Failed to get image!", Toast.LENGTH_LONG ).show()
        super.onActivityResult(requestCode, resultCode, data)
    }


}
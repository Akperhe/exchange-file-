package com.joelson.delgram

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import androidx.activity.viewModels
import androidx.core.view.isVisible
import androidx.fragment.app.viewModels
import androidx.recyclerview.widget.DividerItemDecoration
import androidx.recyclerview.widget.LinearLayoutManager
import com.joelson.delgram.databinding.ActivityChatBinding
import com.joelson.delgram.databinding.ChatItemBinding
import com.joelson.delgram.viewModel.PostViewModel
import com.smith.contactapp.adapter.ChatAdapter

class ChatActivity : AppCompatActivity() {
    private lateinit var binding: ActivityChatBinding
    private lateinit var binding2: ChatItemBinding
    private lateinit var chatAdapter: ChatAdapter
    private val viewModel by viewModels<PostViewModel>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityChatBinding.inflate(layoutInflater)
        setContentView(binding.root)

        chatAdapter = ChatAdapter(listOf())

        binding.chatRecyclerView.apply {
            layoutManager = LinearLayoutManager(this@ChatActivity)
            addItemDecoration(DividerItemDecoration(context, LinearLayoutManager.VERTICAL))
            //hasFixedSize()
            adapter =chatAdapter
        }


            Log.i("image", "glideview")
            viewModel.apply {
                Log.i("image", "glide")
                getAllPost()
                Log.i("image", "glide2")
                post.observe(this@ChatActivity) {
                    chatAdapter.datas = it
                    chatAdapter.notifyDataSetChanged()
                    binding.prog.isVisible = false
                }


            }

        binding.backBtn.setOnClickListener {
            val intent: Intent = Intent(this, MainActivity::class.java)
            startActivity(intent)
        }


    }
}
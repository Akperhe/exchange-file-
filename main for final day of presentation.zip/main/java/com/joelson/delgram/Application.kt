package com.joelson.delgram

import android.app.Application
import com.joelson.delgram.model.SessionManager

class Application :Application() {

    override fun onCreate() {
        super.onCreate()
        sessionManager = SessionManager(this)
    }


    companion object{
        lateinit var sessionManager :SessionManager
    }
}
package com.joelson.delgram

import android.content.Intent
import android.os.Bundle
import android.util.Log
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.isGone
import androidx.core.view.isVisible
import androidx.recyclerview.widget.DividerItemDecoration
import androidx.recyclerview.widget.LinearLayoutManager
import com.bumptech.glide.Glide
import com.joelson.delgram.databinding.ActivityProfileBinding
import com.joelson.delgram.viewModel.MyPostViewModel
import com.smith.contactapp.adapter.MyPostAdapter

class ProfileActivity : AppCompatActivity() {

    private lateinit var binding: ActivityProfileBinding
    private lateinit var myPostAdapter: MyPostAdapter
    private val viewModel by viewModels<MyPostViewModel>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityProfileBinding.inflate(layoutInflater)
        setContentView(binding.root)


        binding.profileUsername.setText(Application.sessionManager.userName.toString())

        binding.fullName.setText("${Application.sessionManager.firstName.toString()} ${Application.sessionManager.lastName.toString()}")
        binding.bioId.setText(Application.sessionManager.bio.toString())

        Log.i("innProfileA", Application.sessionManager.id.toString())
        Log.i("innProfileA", Application.sessionManager.firstName.toString())

        if (Application.sessionManager.profilePicUrl.toString()=="null") {
            binding.imageProfileFragment.setImageResource(R.drawable.profile)
        } else {
            binding.apply {
                Glide.with(imageProfileFragment)
                    .load(Application.sessionManager.profilePicUrl.toString())
                    .into(binding.imageProfileFragment)
            }
        }
           // Log.i("gone",Application.sessionManager.gender.toString())
        if (Application.sessionManager.profilePicUrl.toString() == "null"
            || Application.sessionManager.website.toString() == "null"
            || Application.sessionManager.gender.toString() == "null"
            || Application.sessionManager.email.toString() == "null"
            || Application.sessionManager.firstName.toString()=="null"
            || Application.sessionManager.lastName.toString()=="null"
            || Application.sessionManager.bio.toString()=="null"
            || Application.sessionManager.location.toString()=="null") {
            binding.completeProfile.isGone = false
        } else { binding.completeProfile.isGone = true}


        myPostAdapter = MyPostAdapter(listOf(), this)

        binding.profileFragmentRecycleView.apply {
            //layoutManager = LinearLayoutManager(this@ProfileActivity)
            addItemDecoration(DividerItemDecoration(context, LinearLayoutManager.VERTICAL))
            // hasFixedSize()
            adapter = myPostAdapter
        }


        Log.i("image", "glideview")
        viewModel.apply {
            Log.i("image", "glide")
            getAllMyPost()
            Log.i("image", "glide2")
            post.observe(this@ProfileActivity) {
                myPostAdapter.datas = it
                myPostAdapter.notifyDataSetChanged()
                binding.prog.isVisible = false
            }


        }


        binding.profileBack.setOnClickListener {
            val intent: Intent = Intent(this, MainActivity::class.java)
            startActivity(intent)
        }
        binding.btnEditAccount.setOnClickListener {
            val intent: Intent = Intent(this, EditProfileActivity::class.java)
            startActivity(intent)
        }

    }
}
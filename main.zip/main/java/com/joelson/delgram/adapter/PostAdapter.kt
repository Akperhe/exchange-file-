package com.smith.contactapp.adapter


import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView

import android.annotation.SuppressLint
import android.widget.TextView
import com.bumptech.glide.Glide
import com.joelson.delgram.databinding.PostItemBinding
import com.joelson.delgram.model.Data
import com.joelson.delgram.model.DataX
import com.joelson.delgram.model.PostResponse

import java.text.ParseException
import java.text.SimpleDateFormat
import java.util.*

class PostAdapter(var datas: List<DataX>, var clicker: (DataX) -> Unit) :

    RecyclerView.Adapter<PostAdapter.PostViewHolder>() {

    inner class PostViewHolder(private val binding: PostItemBinding) :
        RecyclerView.ViewHolder(binding.root) {

        fun bind(data: DataX) {
            val time = convertISOTimeToDate(data.dateCreated)

            binding.apply {
                try {
                    Glide.with(imageUpload).load(data.Image_url[0].toString()).into(binding.imageUpload)
                    Glide.with(profileImage).load(data.userid.profilePicture).into(binding.profileImage)
                    username.text = data.userid.userName
                    location.text = data.userid.location
                    commentText.text = data.title

                    var like = data.noOflikes
                    likeTextCount.text = like.toString()
                    userWhoLiked.text= data.userid.userName
                    dateText.text = time
                    Glide.with(likedProfileImage).load(data.userid.profilePicture).into(binding.likedProfileImage)
                    //the above suppos be user who like which is not in back end varable

                    root.setOnClickListener { data?.let {
                        clicker(it)
                    } }
                } catch (e: Exception){
                    0
                }

            }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): PostViewHolder {
        val binding = PostItemBinding.inflate(LayoutInflater.from(parent.context))
        return PostViewHolder(binding)
    }

    override fun onBindViewHolder(holder: PostViewHolder, position: Int) {
        holder.bind(datas[position])
    }

    override fun getItemCount() = datas.size


    @SuppressLint("SimpleDateFormat")
    fun convertISOTimeToDate(isoTime: String): String? {
        val sdf = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS")
        var convertedDate: Date? = null
        var formattedDate: String? = null
        try {
            convertedDate = sdf.parse(isoTime)
            formattedDate = SimpleDateFormat("dd-MM-yy").format(convertedDate!!)
        } catch (e: ParseException) {
            e.printStackTrace()
        }
        return formattedDate
    }

}
package com.joelson.delgram.fragments

import android.os.Bundle
import android.util.Log
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.core.view.isVisible
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.DividerItemDecoration
import androidx.recyclerview.widget.LinearLayoutManager
import com.joelson.delgram.R
import com.joelson.delgram.databinding.FragmentHomeBinding
import com.joelson.delgram.viewModel.PostViewModel
import com.joelson.delgram.viewModel.PostViewModelProviderFactory
import com.smith.contactapp.adapter.PostAdapter


class HomeFragment : Fragment() {

    private lateinit var binding: FragmentHomeBinding
    private lateinit var postAdapter: PostAdapter
    private lateinit var viewModel: PostViewModel

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        arguments?.let {

        }
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        binding = FragmentHomeBinding.inflate(inflater,container,false)

        postAdapter = PostAdapter(listOf()){

        }

        binding.postsRecyclerView.apply {
            layoutManager = LinearLayoutManager(requireContext())
            addItemDecoration(DividerItemDecoration(context, LinearLayoutManager.VERTICAL))
            hasFixedSize()
            adapter =postAdapter
        }

        setupViewModel()

        Log.i("image","glideview")
        viewModel.apply {
Log.i("image","glide")
            getAllPost()
            Log.i("image","glide2")
            post.observe(requireActivity()) {
                postAdapter.datas = it
                postAdapter.notifyDataSetChanged()
                binding.prog.isVisible = false
            }


        }
        return binding.root
    }

    private fun setupViewModel(){
        viewModel = ViewModelProvider(
            requireActivity(),
            PostViewModelProviderFactory()
        )[PostViewModel::class.java]
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

    }






}
package com.joelson.delgram.viewModel

import androidx.lifecycle.ViewModel
import java.lang.IllegalArgumentException
import androidx.lifecycle.ViewModelProvider

class PostViewModelProviderFactory(

//    private val newsRepository: NewsRepository
    ) : ViewModelProvider.Factory{
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            if (modelClass.isAssignableFrom(PostViewModel::class.java)){
                return PostViewModel() as T
            }
            throw IllegalArgumentException("Unknown class name")
        }
}

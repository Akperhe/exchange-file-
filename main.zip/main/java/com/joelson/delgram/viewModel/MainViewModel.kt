package com.joelson.delgram.viewModel

import android.app.Activity
import android.util.Log
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.joelson.delgram.apiService.RetrofitProvider
import com.joelson.delgram.model.*
import com.joelson.delgram.utils.Preferences
import kotlinx.coroutines.*

class MainViewModel(activity: Activity): ViewModel() {
    private val preferences = Preferences(activity)
    private val exceptionHandler = CoroutineExceptionHandler { coroutineContext, throwable ->
        throwable.message?.let { Log.e("Exception!", it) }
    }
    private val coroutineScope = CoroutineScope(Job() + exceptionHandler)

    val message: MutableLiveData<String> = MutableLiveData()
/*
    fun signUp(user: SignUpRequest){
        coroutineScope.launch {
            val response = RetrofitProvider.AUTH.signUpUser(user)
            if (response.isSuccessful){
                val newUser = response.body()
                newUser?.let {
                    UserObject.firstName = it.data.firstName
                    UserObject.lastname = it.data.lastName
                    UserObject.userName = it.data.userName
                    UserObject.email = it.data.userName
                    UserObject.isOnline = it.data.isOnline
                    UserObject.phoneNumber = it.data.phoneNumber
                    UserObject.stack = it.data.stack
                }
                message.postValue("User signed up! with email ${UserObject.email}")
            }else{
                message.postValue(response.message())
            }
        }
    }
*/
    /*
    fun login(user: LoginRequest) {
        coroutineScope.launch {
            val login = RetrofitProvider.AUTH.loginUser(user)
            if (login.isSuccessful){
                val newLogin = login.body()
                newLogin?.let {
                    LoginObject.firstName = it.user.firstName
                    LoginObject.lastname = it.user.lastName
                    LoginObject.userName = it.user.userName
                    LoginObject.email = it.user.email
                    LoginObject.isOnline = it.user.isOnline
                    LoginObject.phoneNumber = it.user.phoneNumber
                    LoginObject.stack = it.user.stack
                }
                message.postValue("User login! with email ${LoginObject.email}")
            } else {
                message.postValue(login.message())
            }

        }
    }
*/
}

package com.joelson.delgram.viewModel

import android.util.Log
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.joelson.delgram.apiService.RetrofitProvider
import com.joelson.delgram.model.*
import kotlinx.coroutines.*
import retrofit2.Call

class LoginViewModel: ViewModel() {
    private val exceptionHandler = CoroutineExceptionHandler { coroutineContext, throwable ->
        throwable.message?.let { Log.e("Exception!", it) }
    }
    private val scope = CoroutineScope(Job() + exceptionHandler)

    val message: MutableLiveData<String> = MutableLiveData()
    val isRegistrationSuccessful: MutableLiveData<Boolean> = MutableLiveData(false)
    val isLoading: MutableLiveData<Boolean> = MutableLiveData(false)


    fun login(user: LoginModel) {
        isLoading.postValue(true)
        scope.launch {
            val response = RetrofitProvider.service.loginUser(user)
            Log.e("ViewModel Response", response.toString())
            if (response.isSuccessful){
                response.body()?.let {
                    UserObject.firstName = it.user.firstName
                    UserObject.lastname = it.user.lastName
                    UserObject.userName = it.user.userName
                    UserObject.email = it.user.email
                    UserObject.isOnline = it.user.isOnline
                    UserObject.phoneNumber = it.user.phoneNumber
                    UserObject.stack = it.user.stack
                    UserObject.token = it.token
                }
                message.postValue("User login! with email ${UserObject.email}")
                isRegistrationSuccessful.postValue(true)
                isLoading.postValue(false)
            } else {
                message.postValue(response.raw().message)
                isLoading.postValue(false)
            }
        }
    }

}
package com.joelson.delgram.viewModel

import android.util.Log
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.joelson.delgram.apiService.RetrofitProvider
import com.joelson.delgram.model.Data
import com.joelson.delgram.model.DataX
import com.joelson.delgram.model.PostResponse
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class PostViewModel : ViewModel() {
    val post: MutableLiveData<List<DataX>> = MutableLiveData()
    var status = MutableLiveData<Int>()

    fun getAllPost() {
        try {
            CoroutineScope(Dispatchers.IO).launch {
                val posts: List<DataX> = RetrofitProvider.service.getAllPost().data
                post.postValue(posts)
            }
        } catch (e: Exception) {
            Log.e("ViewModel", e.message.toString())
        }
    }
}
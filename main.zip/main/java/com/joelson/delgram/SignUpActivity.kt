package com.joelson.delgram

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.lifecycle.ViewModelProvider
import com.joelson.delgram.databinding.ActivitySignUpBinding
import com.joelson.delgram.model.SignupModel
import com.joelson.delgram.viewModel.SignUpViewModel

class SignUpActivity : AppCompatActivity() {
    private lateinit var binding: ActivitySignUpBinding
    private lateinit var sviewModel: SignUpViewModel


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySignUpBinding.inflate(layoutInflater)
        setContentView(binding.root)

        sviewModel = ViewModelProvider(this)[SignUpViewModel::class.java]

        val tvLogin = binding.login
        tvLogin.setOnClickListener {
            val intent: Intent = Intent(this,LoginActivity::class.java)
            startActivity(intent)
        }

        binding.btnSignUp.setOnClickListener {
            addNewUser()
        }

        sviewModel.message.observe(this, {
            Toast.makeText(this, it, Toast.LENGTH_LONG).show()
        })

        sviewModel.isLoading.observe(this, {
            if (it) binding.progress.visibility = View.VISIBLE else binding.progress.visibility = View.GONE
        })
        sviewModel.isRegistrationSuccessful.observe(this) {
            if (it) {
                startActivity(Intent(this, LoginActivity::class.java))
                finish()
            }
        }
    }

    fun addNewUser(){
        val userName: String = binding.username.text.toString()
        val firstName: String = binding.firstName.text.toString()
        val lastName: String = binding.lastName.text.toString()
        val email: String = binding.email.text.toString()
        val phoneNumber: String = binding.phoneNumber.text.toString()
        val stack: String = binding.stackDropdown.toString()
        val password: String = binding.password.text.toString()

        if (userName.isNotEmpty() && firstName.isNotEmpty() && lastName.isNotEmpty()
            && email.isNotEmpty() && phoneNumber !=null
            && stack.isNotEmpty() && password.isNotEmpty()) {

            val newUser = SignupModel(userName, firstName, lastName, email, phoneNumber, stack, password)
            sviewModel.signUp(newUser)

        } else {
            Toast.makeText(this, "Please fill all the fields", Toast.LENGTH_LONG).show()
        }

    }

}
package com.joelson.delgram.utils

enum class Status {
    SUCCESS, LOADING, FAILED, ERROR
}
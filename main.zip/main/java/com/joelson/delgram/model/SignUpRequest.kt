package com.joelson.delgram.model

data class SignUpRequest(
    val userName: String,
    val firstName: String,
    val lastName: String,
    val email: String,
    val phoneNumber: String,
    val stack: String,
    val password: String
)
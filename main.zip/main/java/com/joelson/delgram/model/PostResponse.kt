package com.joelson.delgram.model

data class PostResponse(
    val `data`: List<DataX>,
    val status: String
)
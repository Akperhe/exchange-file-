
package com.joelson.delgram.model

data class SignupResponse(
    val `data`: Data,
    val message: String,
    val status: String
)

data class Data(
    val __v: Int,
    val _id: String,
    val dateCreated: String,
    val email: String,
    val firstName: String,
    val isOnline: Boolean,
    val lastName: String,
    val password: String,
    val phoneNumber: String,
    val stack: String,
    val userName: String
)
package com.joelson.delgram.model

object LoginObject {
    var firstName: String = ""
    var lastname: String = ""
    var userName: String = ""
    var email: String = ""
    var isOnline: Boolean = false
    var phoneNumber: String = ""
    var stack: String = ""
}
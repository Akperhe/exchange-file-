package com.joelson.delgram

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.lifecycle.ViewModelProvider
import com.joelson.delgram.databinding.ActivityLoginBinding
import com.joelson.delgram.model.*
import com.joelson.delgram.viewModel.LoginViewModel


class LoginActivity : AppCompatActivity() {

    private lateinit var binding: ActivityLoginBinding
    private lateinit var sviewModel: LoginViewModel


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityLoginBinding.inflate(layoutInflater)
        setContentView(binding.root)
        sviewModel = ViewModelProvider(this)[LoginViewModel::class.java]

        val tvSignup = binding.signUp
        tvSignup.setOnClickListener {
            val intent: Intent = Intent(this,SignUpActivity::class.java)
            startActivity(intent)
        }

        binding.btnLogin.setOnClickListener {
            loginUser()
        }

        sviewModel.message.observe(this, {
            Toast.makeText(this, it, Toast.LENGTH_LONG).show()
        })

        sviewModel.isLoading.observe(this, {
            if (it) binding.progress.visibility = View.VISIBLE else binding.progress.visibility = View.GONE
        })

        sviewModel.isRegistrationSuccessful.observe(this) {
            if (it) {
                startActivity(Intent(this, MainActivity::class.java))
                finish()
            }
        }
    }


    fun loginUser(){
        val username: String = binding.username.editText?.text.toString()
        val password: String = binding.password.editText?.text.toString()

        if (username.isNotEmpty() && password.isNotEmpty()) {
            val newLogin = LoginModel(username, password)
            sviewModel.apply {
                sviewModel.login(newLogin)
            }
        } else {
            Toast.makeText(this, "Please fill all the fields", Toast.LENGTH_LONG).show()
        }
    }
}

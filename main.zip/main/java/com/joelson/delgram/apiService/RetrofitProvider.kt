package com.joelson.delgram.apiService


import okhttp3.Interceptor
import okhttp3.OkHttpClient
import okhttp3.Response
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import java.util.concurrent.TimeUnit

object RetrofitProvider {

    private val logger = HttpLoggingInterceptor().setLevel(HttpLoggingInterceptor.Level.BODY)

    private val okHttp = OkHttpClient.Builder()

        .addInterceptor(object : Interceptor {
            override fun intercept(chain: Interceptor.Chain): Response {
                return chain.proceed(chain.request().newBuilder().build())
            }
        })
        .addInterceptor(logger)

    val retrofit = Retrofit.Builder()
        .baseUrl("https://ict-del-gram-app.herokuapp.com/")
        .addConverterFactory(GsonConverterFactory.create())
        .client(okHttp.build())
        .build()

    val service: ApiService = retrofit.create (ApiService::class.java)


}
package com.joelson.delgram.apiService

import com.joelson.delgram.model.*

import retrofit2.Response
import retrofit2.http.Body
import retrofit2.http.GET
import retrofit2.http.POST

interface ApiService {

    @POST("api/users/signup")
    suspend fun signUpUser (@Body newUser: SignupModel): Response<SignupResponse>

    @POST ("api/users/login")
    suspend fun loginUser (@Body login: LoginModel): Response<LoginResponse>

    @GET("api/post/allpost")
    suspend fun getAllPost(): PostResponse //List<Data>
}
